use data

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[cash_imp_print]
AS
SELECT        dbo.importer_cashing.Cashingcode, dbo.importer_cashing.chashingdate, dbo.importer_cashing.Accounts_name, dbo.importer_cashing.Amount, dbo.importer_cashing.amount_string, dbo.importer_cashing.cash_type, 
                         dbo.importer_cashing.cash_pay, dbo.importer_cashing.type_pay, dbo.importer_cashing.check_number, dbo.importer_cashing.check_date, dbo.importer_cashing.type_type, dbo.importer_cashing.code_print, 
                         dbo.importer_cashing.push, dbo.importer_cashing.cash_check, dbo.section.code, dbo.section.sec_name, dbo.section.sec_phone, dbo.section.sec_address, dbo.section.sec_email, dbo.section.sec_web, dbo.section.sec_s1, 
                         dbo.section.sec_s2, dbo.section.sec_pic, dbo.section.sec_number, dbo.section.sec_name2
FROM            dbo.importer_cashing INNER JOIN
                         dbo.section ON dbo.importer_cashing.code_print = dbo.section.code




GO
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=1 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'cash_imp_print'
GO